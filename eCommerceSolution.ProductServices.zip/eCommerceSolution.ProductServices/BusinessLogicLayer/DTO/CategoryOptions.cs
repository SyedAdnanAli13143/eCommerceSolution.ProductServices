﻿namespace eCommerce.BusinessLogicLayer.DTO;

public enum CategoryOptions
{
    Electronics, HomeAppliances, Furniture, Accessories
}